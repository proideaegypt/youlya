# LEARNINGS.md — Youlya AI Commerce OS

Codex/Claude must update this only when a real mistake, blocker, or design lesson is discovered.

## 2026-04-28 — Scenario header bug

Problem: `docs/data/youlya_human_test_scenarios.jsonl` contained one fake scenario copied from CSV headers with `id == "id"`.

Fix: final pack removes that row and treats the real scenario count as 90: 80 conversation scenarios and 10 dashboard scenarios.

Rule: validation must reject any scenario where `id` is missing, duplicated, or equals `id`.

## 2026-04-28 — Dashboard scenarios must not run in Phase 0

Problem: dashboard scenarios are useful but should not hit `/api/internal/messages/turn`.

Fix: Playwright defaults to `SCENARIO_PREFIX=CONV`; `DASH` and `ALL` must be explicit.

Rule: Phase 0 E2E acceptance is CONV only.

## 2026-04-28 — Product code cannot be invented

Problem: user asked for products by Shopify name and code. The system cannot safely invent codes.

Fix: define Shopify product title as name and variant SKU as code. Missing SKU is flagged, not invented.

Rule: live product data must come from Shopify API/export only.
